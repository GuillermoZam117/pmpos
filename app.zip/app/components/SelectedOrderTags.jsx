import React from 'react';
import Order from './Order';
import { connect } from 'react-redux'

class SelectedOrderTags extends React.Component {
    render() {
        const {orderTags} = this.props;
        if (!orderTags || orderTags.length === 0) return null;
        return (
            <div className="selectedOrderTags" >
                {orderTags.map(({tag, tagName, price, quantity}) =>
                    <div className='selectedOrderTag' key={tag} style={{ 'backgroundColor': this.getColor(tag) }}>
                        <span className='orderTagQuantity orderTagSection'>{quantity > 1 ? quantity + ' x' : ''}</span>
                        <span className='orderTagName orderTagSection'>{tag}</span>
                        <span className='orderTagPrice orderTagSection'>{price > 0 ? price.toFixed(2) : '' }</span>
                    </div>
                ) }
            </div>
        );
    }

    getColor = (tag) => {
        if (this.props.orderTagColors) {
            var result = this.props.orderTagColors[tag];
            if (result) return result;
        }
        return 'LightGray';
    }
}

const mapStateToProps = state => ({
    orderTagColors: state.menu.get('orderTagColors')
})

export default connect(
    mapStateToProps
)(SelectedOrderTags)